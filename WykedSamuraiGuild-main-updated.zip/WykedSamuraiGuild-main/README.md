# Wyked Samurai Guild

## Structure
- `server/` backend API and OpenAI integration
- `web/` static frontend

## Local development
### Backend
```bash
cd server
npm install
npm run dev
```

### Frontend
Open `web/index.html` in your browser.

## Environment
Create `server/.env`:
```env
PORT=3000
OPENAI_API_KEY=your_key_here
FRONTEND_ORIGIN=*
```
