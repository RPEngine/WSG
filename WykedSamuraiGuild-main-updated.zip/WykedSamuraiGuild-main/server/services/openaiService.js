import OpenAI from "openai";
import { env } from "../config/env.js";

const resumeContext = `
You are Penny Carter's AI resume assistant.

Information about Penny:
- Penny Carter is pursuing a Bachelor's in Human Resource Management at Southern New Hampshire University.
- She has leadership experience in retail and restaurant environments.
- Her strengths include training, onboarding, conflict resolution, scheduling, compliance awareness, customer service leadership, and team development.
- She is seeking entry-level HR, onboarding, people operations, and workforce support roles.

Rules:
- Be accurate.
- Do not invent experience.
- If something is not in the profile, say: "That information is not currently included in Penny's profile."
- Keep replies clear and professional.
`;

const client = env.openaiApiKey ? new OpenAI({ apiKey: env.openaiApiKey }) : null;

export async function getResumeAssistantReply(userMessage) {
  if (!userMessage || !userMessage.trim()) {
    throw new Error("A message is required.");
  }

  if (!client) {
    return "The AI service is wired up, but OPENAI_API_KEY is not set yet. Add your key in server/.env or Render environment variables.";
  }

  const response = await client.responses.create({
    model: "gpt-5.2",
    instructions: resumeContext,
    input: userMessage.trim()
  });

  return response.output_text || "The assistant could not generate a response.";
}
