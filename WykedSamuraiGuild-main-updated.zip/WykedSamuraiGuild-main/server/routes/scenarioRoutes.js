import { Router } from "express";
import { getScenarioResponses, postScenarioResponse } from "../controllers/scenarioController.js";

const router = Router();
router.get("/", getScenarioResponses);
router.post("/", postScenarioResponse);

export default router;
