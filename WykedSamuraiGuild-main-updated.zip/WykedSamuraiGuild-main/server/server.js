import express from "express";
import cors from "cors";
import { env } from "./config/env.js";
import chatRoutes from "./routes/chatRoutes.js";
import scenarioRoutes from "./routes/scenarioRoutes.js";

const app = express();

app.use(cors({ origin: env.frontendOrigin === "*" ? true : env.frontendOrigin }));
app.use(express.json());

app.get("/api/health", (req, res) => {
  res.json({ ok: true, message: "Server is running" });
});

app.use("/api/chat", chatRoutes);
app.use("/api/scenarios", scenarioRoutes);

app.use((req, res) => {
  res.status(404).json({ ok: false, error: "Route not found." });
});

app.listen(env.port, () => {
  console.log(`Server running on port ${env.port}`);
});
