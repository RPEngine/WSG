import crypto from "crypto";

const scenarioResponses = [];

export function getScenarioResponses(req, res) {
  return res.json({ ok: true, data: scenarioResponses });
}

export function postScenarioResponse(req, res) {
  const { name, approach, response } = req.body;

  if (!name || !name.trim() || !response || !response.trim()) {
    return res.status(400).json({ ok: false, error: "Name and response are required." });
  }

  const entry = {
    id: crypto.randomUUID(),
    name: name.trim(),
    approach: approach?.trim() || "Unspecified",
    response: response.trim(),
    createdAt: new Date().toISOString()
  };

  scenarioResponses.unshift(entry);

  return res.status(201).json({
    ok: true,
    message: "Scenario response saved.",
    data: entry
  });
}
