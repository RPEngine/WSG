import { getResumeAssistantReply } from "../services/openaiService.js";

export async function postChat(req, res) {
  try {
    const { message } = req.body;

    if (!message || !message.trim()) {
      return res.status(400).json({ ok: false, error: "Message is required." });
    }

    const reply = await getResumeAssistantReply(message);
    return res.json({ ok: true, reply });
  } catch (error) {
    console.error("Chat controller error:", error);
    return res.status(500).json({ ok: false, error: "Server error while generating reply." });
  }
}
