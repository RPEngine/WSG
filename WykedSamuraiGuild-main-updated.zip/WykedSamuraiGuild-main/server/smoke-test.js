const base = `http://127.0.0.1:${process.env.PORT || 3000}/api`;

async function run() {
  const health = await fetch(`${base}/health`).then(r => r.json());
  console.log('health', health);

  const postScenario = await fetch(`${base}/scenarios`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: 'Penny', approach: 'Mediator', response: 'Stabilize the team and collect facts.' })
  }).then(r => r.json());
  console.log('post scenario', postScenario);

  const getScenarios = await fetch(`${base}/scenarios`).then(r => r.json());
  console.log('get scenarios', getScenarios);

  const chat = await fetch(`${base}/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message: 'What strengths should be highlighted for HR roles?' })
  }).then(r => r.json());
  console.log('chat', chat);
}

run().catch(err => {
  console.error(err);
  process.exit(1);
});
