const API_BASE = window.location.hostname === "localhost"
  ? "http://localhost:3000/api"
  : "https://your-render-backend-url.onrender.com/api";

const form = document.getElementById("scenario-form");
const output = document.getElementById("scenario-output");
const list = document.getElementById("scenario-list");

async function loadResponses() {
  try {
    const response = await fetch(`${API_BASE}/scenarios`);
    const data = await response.json();

    if (!response.ok) throw new Error(data.error || "Could not load responses.");
    if (!data.data.length) {
      list.textContent = "No responses yet.";
      return;
    }

    list.innerHTML = data.data.map((item) => `
      <div style="margin-bottom:16px;padding-bottom:16px;border-bottom:1px solid #2f4658;">
        <strong>${item.name}</strong> (${item.approach})<br>
        <small>${new Date(item.createdAt).toLocaleString()}</small>
        <p>${item.response}</p>
      </div>
    `).join("");
  } catch (error) {
    list.textContent = `Error: ${error.message}`;
  }
}

form?.addEventListener("submit", async (event) => {
  event.preventDefault();
  const payload = {
    name: document.getElementById("name").value.trim(),
    approach: document.getElementById("approach").value,
    response: document.getElementById("response").value.trim()
  };

  if (!payload.name || !payload.response) {
    output.textContent = "Name and response are required.";
    return;
  }

  output.textContent = "Submitting...";
  try {
    const response = await fetch(`${API_BASE}/scenarios`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Submission failed.");

    output.textContent = data.message;
    form.reset();
    loadResponses();
  } catch (error) {
    output.textContent = `Error: ${error.message}`;
  }
});

loadResponses();
