console.log("SCRIPT LOADED");

document.getElementById("scenarioForm").addEventListener("submit", async (e) => {
    e.preventDefault();

    const responseText = document.getElementById("response").value;
    const statusMessage = document.getElementById("statusMessage");

    statusMessage.textContent = "Submitting...";

    try {
        const res = await fetch("https://YOUR-RENDER-APP.onrender.com/scenario", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ response: responseText })
        });

        const data = await res.json();

        if (data.status === "success") {
            statusMessage.textContent = "Response submitted successfully.";
            document.getElementById("response").value = "";
        } else {
            statusMessage.textContent = "Error submitting response.";
        }
    } catch (err) {
        console.error(err);
        statusMessage.textContent = "Server error.";
    }
});
