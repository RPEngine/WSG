const API_BASE = window.location.hostname === "localhost"
  ? "http://localhost:3000/api"
  : "https://your-render-backend-url.onrender.com/api";

const chatForm = document.getElementById("chat-form");
const messageInput = document.getElementById("message");
const chatOutput = document.getElementById("chat-output");
const healthOutput = document.getElementById("health-output");

async function checkHealth() {
  try {
    const response = await fetch(`${API_BASE}/health`);
    const data = await response.json();
    healthOutput.textContent = data.ok ? `Backend: ${data.message}` : "Backend check failed.";
  } catch (error) {
    healthOutput.textContent = `Backend: offline or not configured yet.`;
  }
}

chatForm?.addEventListener("submit", async (event) => {
  event.preventDefault();
  const message = messageInput.value.trim();
  if (!message) {
    chatOutput.textContent = "Please enter a question.";
    return;
  }

  chatOutput.textContent = "Thinking...";

  try {
    const response = await fetch(`${API_BASE}/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message })
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Request failed.");
    chatOutput.textContent = data.reply;
  } catch (error) {
    chatOutput.textContent = `Error: ${error.message}`;
  }
});

checkHealth();
